from zoho_eclean.dns_lookup import lookup_domain
from zoho_eclean.models import DNSResult, EmailResult
from zoho_eclean.validation import normalize_email

PERSONAL_ZOHO_DOMAINS = {"zoho.com", "zohomail.com"}
PROVIDER_SIGNATURES = {
    "Zoho Mail": ("zoho.com", "zoho.eu", "zoho.in", "zoho.com.au", "zoho.jp", "zoho.com.cn"),
    "Microsoft 365": ("protection.outlook.com",),
    "Google Workspace": ("aspmx.l.google.com", "googlemail.com"),
    "Proofpoint": ("pphosted.com", "ppe-hosted.com"),
    "Mimecast": ("mimecast.com",),
    "Barracuda": ("barracudanetworks.com",),
    "OpenText AppRiver": ("appriver.com", "mxlogic.net"),
}
DISPOSABLE_DOMAINS = {
    "10minutemail.com",
    "guerrillamail.com",
    "mailinator.com",
    "tempmail.com",
    "yopmail.com",
}


def identify_provider(mx_records: list[str]) -> tuple[str, int]:
    hosts = [record.partition(" ")[2].lower() for record in mx_records]
    for provider, signatures in PROVIDER_SIGNATURES.items():
        if any(
            host == signature or host.endswith(f".{signature}")
            for signature in signatures
            for host in hosts
        ):
            return provider, 95
    return ("Unknown / custom", 0) if hosts else ("No MX records", 0)


def analyze(
    value: str,
    timeout: float = 3.0,
    dns_result: DNSResult | None = None,
    check_dns: bool = True,
    syntax_result: tuple[str | None, str | None] | None = None,
) -> EmailResult:
    normalized, syntax_error = syntax_result or normalize_email(value)
    if normalized is None:
        return EmailResult(
            input_email=value.strip(),
            email=value.strip(),
            valid_syntax=False,
            syntax_error=syntax_error or "Invalid email address.",
            domain="",
            account_type="Unknown",
            provider="Not checked",
            provider_confidence=0,
            mx_records=[],
            spf_records=[],
            txt_records=[],
            ns_records=[],
            dns_errors={},
            risk_score=0,
            risk_level="Not assessed",
            findings=["Email syntax is invalid; DNS and risk checks were skipped."],
        )

    domain = normalized.rsplit("@", 1)[1].lower()
    if not check_dns:
        return EmailResult(
            input_email=value.strip(),
            email=normalized,
            valid_syntax=True,
            syntax_error="",
            domain=domain,
            account_type="Zoho Mail personal domain" if domain in PERSONAL_ZOHO_DOMAINS else "Not checked",
            provider="Not checked",
            provider_confidence=0,
            mx_records=[],
            spf_records=[],
            txt_records=[],
            ns_records=[],
            dns_errors={},
            risk_score=0,
            risk_level="Not assessed",
            findings=["Public DNS enrichment was not requested; mailbox existence was not tested."],
        )

    records = dns_result if dns_result is not None else lookup_domain(domain, timeout)
    provider, confidence = identify_provider(records.mx)
    if not records.mx and "mx" in records.errors:
        provider, confidence = "DNS lookup failed", 0
    spf_records = [record for record in records.txt if record.lower().startswith("v=spf1")]

    if domain in PERSONAL_ZOHO_DOMAINS:
        account_type = "Zoho Mail personal domain"
    elif provider == "Zoho Mail":
        account_type = "Zoho-hosted business/custom domain"
    else:
        account_type = "Other or unconfirmed domain"

    findings: list[str] = []
    risk_score = 0
    if not records.mx and "mx" not in records.errors:
        findings.append("No MX records were found; mail routing may not be configured.")
        risk_score += 50
    if "txt" in records.errors:
        findings.append("TXT lookup failed; SPF status could not be determined.")
    elif records.txt and not spf_records:
        findings.append("No SPF record was found in the domain TXT records.")
        risk_score += 15
    elif not records.txt and "txt" not in records.errors:
        findings.append("No TXT records were found; SPF could not be confirmed.")
        risk_score += 15
    if domain in DISPOSABLE_DOMAINS:
        findings.append("Domain is on the application's small built-in disposable-domain list.")
        risk_score += 25
    if records.errors:
        findings.append("One or more DNS queries failed; results may be incomplete.")
    if not findings:
        findings.append("No configured risk indicators were detected.")

    risk_score = min(risk_score, 100)
    risk_level = (
        "Incomplete"
        if records.errors
        else "High" if risk_score >= 60
        else "Medium" if risk_score >= 25
        else "Low"
    )

    return EmailResult(
        input_email=value.strip(),
        email=normalized,
        valid_syntax=True,
        syntax_error="",
        domain=domain,
        account_type=account_type,
        provider=provider,
        provider_confidence=confidence,
        mx_records=records.mx,
        spf_records=spf_records,
        txt_records=records.txt,
        ns_records=records.ns,
        dns_errors=records.errors,
        risk_score=risk_score,
        risk_level=risk_level,
        findings=findings,
    )
