import dns.exception
import dns.resolver

from zoho_eclean.models import DNSResult


def lookup_domain(domain: str, timeout: float = 3.0) -> DNSResult:
    resolver = dns.resolver.Resolver()
    resolver.timeout = timeout
    resolver.lifetime = timeout
    answers: dict[str, list[str]] = {"mx": [], "txt": [], "ns": []}
    errors: dict[str, str] = {}

    for record_type in ("MX", "TXT", "NS"):
        key = record_type.lower()
        try:
            response = resolver.resolve(domain, record_type)
            if record_type == "MX":
                answers[key] = sorted(
                    f"{record.preference} {str(record.exchange).rstrip('.')}"
                    for record in response
                )
            elif record_type == "TXT":
                answers[key] = sorted(
                    b"".join(record.strings).decode("utf-8", errors="replace")
                    for record in response
                )
            else:
                answers[key] = sorted(str(record.target).rstrip(".") for record in response)
        except dns.resolver.NoAnswer:
            answers[key] = []
        except dns.resolver.NXDOMAIN:
            errors[key] = "Domain does not exist (NXDOMAIN)."
        except (dns.resolver.NoNameservers, dns.exception.Timeout, dns.resolver.LifetimeTimeout) as exc:
            errors[key] = f"DNS query failed: {exc.__class__.__name__}."
        except dns.exception.DNSException as exc:
            errors[key] = f"DNS query failed: {exc.__class__.__name__}."

    return DNSResult(
        mx=answers["mx"],
        txt=answers["txt"],
        ns=answers["ns"],
        errors=errors,
    )
