import argparse
import sys
from pathlib import Path

from zoho_eclean import __version__
from zoho_eclean.batch import MAX_DNS_WORKERS, process_file


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="zoho-eclean",
        description="Run batch analysis. Launch without arguments for the interactive dashboard.",
        epilog="This tool does not verify mailbox existence, sign in, or test SMTP credentials.",
    )
    parser.add_argument("--version", action="version", version=f"Zoho eClean {__version__}")
    parser.add_argument("--input", type=Path, help="Input .txt (one email per line) or .csv (email column).")
    parser.add_argument("--syntax-only", action="store_true", help="Skip public DNS lookups.")
    parser.add_argument("--output-dir", type=Path, default=Path("reports") / "output")
    parser.add_argument("--timeout", type=float, default=3.0, help="DNS timeout in seconds (default: 3).")
    parser.add_argument("--workers", type=int, default=MAX_DNS_WORKERS, help=f"DNS workers (1-{MAX_DNS_WORKERS}).")
    return parser


def main(argv: list[str] | None = None) -> int:
    arguments = sys.argv[1:] if argv is None else argv
    if not arguments:
        from zoho_eclean.dashboard import run

        return run()

    parser = build_parser()
    args = parser.parse_args(arguments)
    if args.input is None:
        parser.error("--input is required in batch mode. Run without options for the dashboard.")
    try:
        summary = process_file(
            args.input,
            args.output_dir,
            check_dns=not args.syntax_only,
            timeout=args.timeout,
            workers=args.workers,
        )
    except (OSError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2

    print(
        f"Processed {summary['processed']:,} | syntax-valid {summary['valid']:,} "
        f"| invalid {summary['invalid']:,} | {summary['duration']:.2f}s"
    )
    for path in summary["files"]:
        print(f"Report: {path}")
    return 0
