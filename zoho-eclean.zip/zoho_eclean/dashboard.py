import os
import subprocess
import sys
from pathlib import Path

import questionary
from colorama import Fore, Style, just_fix_windows_console
from questionary import Choice, Style as QuestionaryStyle

from zoho_eclean import __version__
from zoho_eclean.batch import MAX_DNS_WORKERS, process_file
from zoho_eclean.telegram import TelegramUploadError, send_document

APP_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_INPUT_DIR = APP_ROOT / "data" / "input"
OUTPUT_DIR = APP_ROOT / "reports" / "output"
MENU_STYLE = QuestionaryStyle(
    [
        ("qmark", "fg:#00bcd4 bold"),
        ("question", "fg:#e8f1ff bold"),
        ("answer", "fg:#00d084 bold"),
        ("pointer", "fg:#00bcd4 bold"),
        ("highlighted", "fg:#00bcd4 bold"),
        ("selected", "fg:#00d084"),
        ("separator", "fg:#65758b"),
    ]
)


def _header() -> None:
    print(Fore.CYAN + Style.BRIGHT + "=" * 60)
    print("  ZOHO eCLEAN  |  EMAIL SYNTAX + DOMAIN INTELLIGENCE")
    print(f"  Version {__version__}  |  Local-first  |  Batch-ready")
    print("=" * 60 + Style.RESET_ALL)


def _select(prompt: str, choices: list[Choice]) -> object:
    return questionary.select(prompt, choices=choices, style=MENU_STYLE, qmark=">").ask()


def _choose_input_file(input_dir: Path) -> Path | None:
    input_dir.mkdir(parents=True, exist_ok=True)
    files = sorted(
        path for path in input_dir.iterdir()
        if path.is_file() and path.suffix.lower() in {".txt", ".csv"}
    )
    if not files:
        print(Fore.YELLOW + f"No .txt or .csv lists found in: {input_dir}" + Style.RESET_ALL)
        print("Copy your input list into that folder, then choose this option again.")
        return None
    selected = _select(
        f"Choose a list from {input_dir}:",
        [Choice(title=f"{path.name}  ({path.stat().st_size:,} bytes)", value=path) for path in files]
        + [Choice(title="Back", value=None)],
    )
    return selected if isinstance(selected, Path) else None


def _run_batch(input_path: Path) -> None:
    mode = _select(
        "Analysis mode:",
        [
            Choice("Fast syntax-only (recommended for very large lists)", value=False),
            Choice("Add public DNS/provider intelligence (one lookup set per unique domain)", value=True),
            Choice("Back", value=None),
        ],
    )
    if mode is None:
        return
    check_dns = bool(mode)
    workers = MAX_DNS_WORKERS
    if check_dns:
        workers_choice = _select(
            "DNS concurrency (bounded to protect resolver reliability):",
            [Choice(str(value), value=value) for value in (4, 8, 16)],
        )
        if workers_choice is None:
            return
        workers = int(workers_choice)
        if not questionary.confirm(
            "DNS checks query public domain records only; mailbox existence is not checked. Continue?",
            default=True,
            style=MENU_STYLE,
        ).ask():
            return

    print(Fore.CYAN + f"\nReading {input_path.name} in bounded chunks..." + Style.RESET_ALL)
    last_progress = 0

    def show_progress(processed: int, valid: int, invalid: int) -> None:
        nonlocal last_progress
        if processed - last_progress >= 1000:
            print(
                Fore.CYAN
                + f"\rProcessed {processed:,}  |  syntax-valid {valid:,}  |  invalid {invalid:,}"
                + Style.RESET_ALL,
                end="",
                flush=True,
            )
            last_progress = processed

    try:
        result = process_file(
            input_path,
            OUTPUT_DIR,
            check_dns=check_dns,
            workers=workers,
            progress=show_progress,
        )
    except (OSError, ValueError) as exc:
        print(Fore.RED + f"\nProcessing failed: {exc}" + Style.RESET_ALL)
        return

    if result["processed"] >= 1000:
        print()
    print(Fore.GREEN + Style.BRIGHT + "\nCompleted" + Style.RESET_ALL)
    print(
        f"Processed: {result['processed']:,}  |  Valid syntax: {result['valid']:,}  "
        f"|  Invalid syntax: {result['invalid']:,}  |  Time: {result['duration']:.2f}s"
    )
    print(Fore.YELLOW + "Syntax-valid does not mean mailbox exists or can receive mail." + Style.RESET_ALL)
    print("\nGenerated files:")
    for path in result["files"]:
        print(Fore.GREEN + f"  {path}" + Style.RESET_ALL)


def _send_reports() -> None:
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.environ.get("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id:
        print(
            Fore.YELLOW
            + "Telegram bot credentials are needed. The token is entered hidden and kept in memory "
            "for this run only."
            + Style.RESET_ALL
        )
        token = questionary.password("Telegram bot token:", style=MENU_STYLE, qmark=">").ask()
        chat_id = questionary.text("Telegram chat ID:", style=MENU_STYLE, qmark=">").ask()
        if not token or not chat_id:
            print(Fore.YELLOW + "Telegram upload cancelled." + Style.RESET_ALL)
            return

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    reports = sorted(
        path for path in OUTPUT_DIR.iterdir()
        if path.is_file() and path.suffix.lower() in {".txt", ".json"}
    )
    if not reports:
        print(Fore.YELLOW + f"No TXT or JSON reports found in {OUTPUT_DIR}." + Style.RESET_ALL)
        return
    selected = questionary.checkbox(
        "Select report files to upload to Telegram (these may contain email addresses):",
        choices=[
            Choice(title=f"{path.name}  ({path.stat().st_size / (1024 * 1024):.2f} MB)", value=path)
            for path in reports
        ],
        style=MENU_STYLE,
        qmark=">",
    ).ask()
    if not selected:
        return
    print("\nSelected files are uploaded to the Telegram chat configured by your bot.")
    if not questionary.confirm(
        "I own/control that chat and approve sending these report files. Continue?",
        default=False,
        style=MENU_STYLE,
    ).ask():
        return

    for path in selected:
        try:
            send_document(path, token=token, chat_id=chat_id)
        except (OSError, TelegramUploadError) as exc:
            print(Fore.RED + f"Upload failed for {path.name}: {exc}" + Style.RESET_ALL)
            continue
        print(Fore.GREEN + f"Uploaded {path.name}" + Style.RESET_ALL)


def _open_folder(folder: Path) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    try:
        if os.name == "nt":
            os.startfile(folder)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(folder)])
        else:
            subprocess.Popen(["xdg-open", str(folder)])
    except OSError as exc:
        print(Fore.RED + f"Could not open folder: {exc}" + Style.RESET_ALL)


def _run_menu() -> int:
    input_dir = DEFAULT_INPUT_DIR
    while True:
        print("\n")
        _header()
        print(Fore.WHITE + f"Input folder : {input_dir}")
        print(Fore.WHITE + f"Reports      : {OUTPUT_DIR}" + Style.RESET_ALL)
        action = _select(
            "What would you like to do?",
            [
                Choice("Process a list", value="process"),
                Choice("Change input folder", value="folder"),
                Choice("Open input folder", value="open_input"),
                Choice("Send TXT/JSON reports to Telegram", value="telegram"),
                Choice("Open reports folder", value="open"),
                Choice("Exit", value="exit"),
            ],
        )
        if action in (None, "exit"):
            print(Fore.CYAN + "Zoho eClean closed." + Style.RESET_ALL)
            return 0
        if action == "process":
            input_path = _choose_input_file(input_dir)
            if input_path:
                _run_batch(input_path)
        elif action == "folder":
            entered = questionary.path(
                "Enter the folder containing .txt/.csv input lists:",
                default=str(input_dir),
                style=MENU_STYLE,
            ).ask()
            if entered:
                candidate = Path(entered).expanduser()
                if candidate.is_dir():
                    input_dir = candidate.resolve()
                else:
                    print(Fore.RED + "That folder does not exist." + Style.RESET_ALL)
        elif action == "telegram":
            _send_reports()
        elif action == "open_input":
            _open_folder(input_dir)
        elif action == "open":
            _open_folder(OUTPUT_DIR)


def run() -> int:
    just_fix_windows_console()
    try:
        return _run_menu()
    except (KeyboardInterrupt, EOFError):
        print("\n" + Fore.CYAN + "Zoho eClean closed." + Style.RESET_ALL)
        return 0


if __name__ == "__main__":
    raise SystemExit(run())
