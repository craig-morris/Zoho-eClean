from dataclasses import asdict, dataclass
from typing import Any


@dataclass
class DNSResult:
    mx: list[str]
    txt: list[str]
    ns: list[str]
    errors: dict[str, str]


@dataclass
class EmailResult:
    input_email: str
    email: str
    valid_syntax: bool
    syntax_error: str
    domain: str
    account_type: str
    provider: str
    provider_confidence: int
    mx_records: list[str]
    spf_records: list[str]
    txt_records: list[str]
    ns_records: list[str]
    dns_errors: dict[str, str]
    risk_score: int
    risk_level: str
    findings: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
