"""Zoho eClean: email syntax and public domain DNS intelligence."""

__version__ = "1.0.0"
