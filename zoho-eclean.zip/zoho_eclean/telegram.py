import os
from pathlib import Path

import requests

TELEGRAM_MAX_UPLOAD_BYTES = 50 * 1024 * 1024


class TelegramUploadError(RuntimeError):
    pass


def credentials_available() -> bool:
    return bool(os.environ.get("TELEGRAM_BOT_TOKEN") and os.environ.get("TELEGRAM_CHAT_ID"))


def send_document(path: Path, token: str | None = None, chat_id: str | None = None) -> None:
    token = (token or os.environ.get("TELEGRAM_BOT_TOKEN", "")).strip()
    chat_id = (chat_id or os.environ.get("TELEGRAM_CHAT_ID", "")).strip()
    if not token or not chat_id:
        raise TelegramUploadError("Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in the environment first.")
    if path.suffix.lower() not in {".txt", ".json"}:
        raise TelegramUploadError("Only TXT and JSON report files can be uploaded.")
    if not path.is_file():
        raise FileNotFoundError(f"Report file not found: {path}")
    if path.stat().st_size > TELEGRAM_MAX_UPLOAD_BYTES:
        raise TelegramUploadError("This file exceeds Telegram's 50 MB bot upload limit.")

    endpoint = f"https://api.telegram.org/bot{token}/sendDocument"
    try:
        with path.open("rb") as document:
            response = requests.post(
                endpoint,
                data={"chat_id": chat_id, "caption": f"Zoho eClean report: {path.name}"},
                files={"document": (path.name, document)},
                timeout=(10, 180),
            )
        response.raise_for_status()
    except requests.RequestException as exc:
        raise TelegramUploadError(
            f"Telegram upload failed ({exc.__class__.__name__}); check network access and bot configuration."
        ) from None

    try:
        result = response.json()
    except ValueError:
        raise TelegramUploadError("Telegram returned an unreadable response.") from None
    if not isinstance(result, dict):
        raise TelegramUploadError("Telegram returned an unexpected response.")
    if not result.get("ok"):
        raise TelegramUploadError(f"Telegram rejected the upload: {result.get('description', 'unknown error')}")
