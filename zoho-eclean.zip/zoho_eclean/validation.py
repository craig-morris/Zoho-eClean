from email_validator import EmailNotValidError, validate_email


def normalize_email(value: str) -> tuple[str | None, str | None]:
    """Validate syntax and normalize without checking mailbox deliverability."""
    candidate = value.strip()
    if not candidate:
        return None, "Email address is empty."

    try:
        parsed = validate_email(candidate, check_deliverability=False)
    except EmailNotValidError as exc:
        return None, str(exc)
    return parsed.normalized, None
