import csv
import json
import time
from collections import Counter
from contextlib import ExitStack
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from itertools import islice
from pathlib import Path
from typing import Callable, Iterator

from zoho_eclean.analysis import analyze
from zoho_eclean.dns_lookup import lookup_domain
from zoho_eclean.models import DNSResult, EmailResult
from zoho_eclean.validation import normalize_email

CHUNK_SIZE = 500
MAX_DNS_WORKERS = 16
MAX_JSON_PART_BYTES = 20 * 1024 * 1024


def iter_emails(path: Path) -> Iterator[str]:
    if path.suffix.lower() not in {".txt", ".csv"}:
        raise ValueError("Choose a .txt file (one email per line) or .csv file (with an email column).")

    with path.open("r", encoding="utf-8-sig", newline="") as file:
        if path.suffix.lower() == ".csv":
            reader = csv.DictReader(file)
            if not reader.fieldnames or "email" not in {name.strip().lower() for name in reader.fieldnames}:
                raise ValueError("CSV input must contain a column named 'email'.")
            email_column = next(name for name in reader.fieldnames if name.strip().lower() == "email")
            for row in reader:
                value = (row.get(email_column) or "").strip()
                if value and not value.startswith("#"):
                    yield value
        else:
            for line in file:
                value = line.strip()
                if value and not value.startswith("#"):
                    yield value


def _chunks(values: Iterator[str], size: int) -> Iterator[list[str]]:
    while chunk := list(islice(values, size)):
        yield chunk


def process_file(
    input_path: Path,
    output_dir: Path,
    *,
    check_dns: bool,
    timeout: float = 2.0,
    workers: int = MAX_DNS_WORKERS,
    progress: Callable[[int, int, int], None] | None = None,
) -> dict[str, object]:
    if timeout <= 0:
        raise ValueError("DNS timeout must be greater than zero.")
    if workers < 1 or workers > MAX_DNS_WORKERS:
        raise ValueError(f"DNS workers must be between 1 and {MAX_DNS_WORKERS}.")
    if not input_path.is_file():
        raise FileNotFoundError(f"Input file not found: {input_path}")

    output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    summary_path = output_dir / f"validation_summary_{stamp}.txt"
    valid_path = output_dir / f"syntax_valid_emails_{stamp}.txt"
    invalid_path = output_dir / f"invalid_syntax_emails_{stamp}.txt"
    json_paths: list[Path] = []

    processed = valid_count = invalid_count = zoho_count = 0
    providers: Counter[str] = Counter()
    risks: Counter[str] = Counter()
    domain_cache: dict[str, DNSResult] = {}
    started = time.perf_counter()

    with ExitStack() as stack:
        valid_file = stack.enter_context(valid_path.open("w", encoding="utf-8", newline="\n"))
        invalid_file = stack.enter_context(invalid_path.open("w", encoding="utf-8", newline="\n"))
        executor = stack.enter_context(ThreadPoolExecutor(max_workers=workers if check_dns else 1))
        json_file = None
        first_result = True
        for chunk in _chunks(iter_emails(input_path), CHUNK_SIZE):
            normalized = [normalize_email(value) for value in chunk]
            if check_dns:
                domains = {
                    email.rsplit("@", 1)[1].lower()
                    for email, error in normalized
                    if email is not None and error is None
                }
                missing = domains.difference(domain_cache)
                futures = {
                    executor.submit(lookup_domain, domain, timeout): domain
                    for domain in missing
                }
                for future in as_completed(futures):
                    domain_cache[futures[future]] = future.result()

            for raw, (email, error) in zip(chunk, normalized):
                if email is None or error is not None:
                    result = analyze(
                        raw,
                        check_dns=False,
                        syntax_result=(email, error),
                    )
                    invalid_file.write(raw + "\n")
                    invalid_count += 1
                else:
                    domain = email.rsplit("@", 1)[1].lower()
                    result = analyze(
                        raw,
                        dns_result=domain_cache[domain] if check_dns else None,
                        check_dns=check_dns,
                        syntax_result=(email, error),
                    )
                    valid_file.write(result.email + "\n")
                    valid_count += 1
                    if result.provider == "Zoho Mail" or result.account_type == "Zoho Mail personal domain":
                        zoho_count += 1
                    if result.provider != "Not checked":
                        providers[result.provider] += 1
                    if result.risk_level != "Not assessed":
                        risks[result.risk_level] += 1

                serialized = json.dumps(result.to_dict(), ensure_ascii=False, separators=(",", ":"))
                record_bytes = len(serialized.encode("utf-8")) + (2 if not first_result else 0)
                if json_file is None or (
                    json_file.tell() + record_bytes + 3 > MAX_JSON_PART_BYTES
                    and json_file.tell() > 2
                ):
                    if json_file is not None:
                        json_file.write("\n]\n")
                    json_path = output_dir / f"validation_report_{stamp}_{len(json_paths) + 1:03}.json"
                    json_paths.append(json_path)
                    json_file = stack.enter_context(json_path.open("w", encoding="utf-8", newline="\n"))
                    json_file.write("[\n")
                    first_result = True
                if not first_result:
                    json_file.write(",\n")
                json_file.write(serialized)
                first_result = False

            processed += len(chunk)
            if progress is not None:
                progress(processed, valid_count, invalid_count)

        if json_file is not None:
            json_file.write("\n]\n")

    duration = time.perf_counter() - started
    summary_path.write_text(
        _format_summary(
            input_path=input_path,
            processed=processed,
            valid=valid_count,
            invalid=invalid_count,
            zoho=zoho_count,
            providers=providers,
            risks=risks,
            duration=duration,
            check_dns=check_dns,
        ),
        encoding="utf-8",
    )
    return {
        "processed": processed,
        "valid": valid_count,
        "invalid": invalid_count,
        "zoho": zoho_count,
        "providers": dict(providers),
        "risks": dict(risks),
        "duration": duration,
        "files": [summary_path, valid_path, invalid_path, *json_paths],
    }


def _format_summary(
    *,
    input_path: Path,
    processed: int,
    valid: int,
    invalid: int,
    zoho: int,
    providers: Counter[str],
    risks: Counter[str],
    duration: float,
    check_dns: bool,
) -> str:
    lines = [
        "=" * 48,
        "Zoho eClean Summary",
        "=" * 48,
        f"Input file             : {input_path.name}",
        f"Processed              : {processed}",
        f"Valid syntax           : {valid}",
        f"Invalid syntax         : {invalid}",
        f"Zoho-associated emails : {zoho}" if check_dns else "Zoho-associated      : DNS not checked",
        "",
    ]
    if check_dns:
        lines.extend(f"{provider:24}: {count}" for provider, count in sorted(providers.items()))
        lines.append("")
        lines.extend(f"{risk + ' risk':24}: {risks.get(risk, 0)}" for risk in ("Low", "Medium", "High", "Incomplete"))
        lines.append("")
    lines.extend(
        [
            f"Duration (seconds)     : {duration:.2f}",
            "",
            "Valid syntax is not confirmation that a mailbox exists or can receive mail.",
            "DNS/provider results are domain-level indicators only.",
            "=" * 48,
            "",
        ]
    )
    return "\n".join(lines)
