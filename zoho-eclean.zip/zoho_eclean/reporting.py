import csv
import html
import json
from pathlib import Path

from zoho_eclean.models import EmailResult


CSV_FIELDS = [
    "input_email", "email", "valid_syntax", "domain", "account_type",
    "provider", "provider_confidence", "risk_score", "risk_level",
    "mx_records", "spf_records", "findings", "dns_errors",
]


def write_report(results: list[EmailResult], output_dir: Path, formats: list[str]) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    for report_format in formats:
        path = output_dir / f"zoho_eclean_report.{report_format}"
        if report_format == "json":
            path.write_text(
                json.dumps([result.to_dict() for result in results], indent=2),
                encoding="utf-8",
            )
        elif report_format == "csv":
            with path.open("w", newline="", encoding="utf-8-sig") as file:
                writer = csv.DictWriter(file, fieldnames=CSV_FIELDS)
                writer.writeheader()
                for result in results:
                    row = result.to_dict()
                    for key in ("mx_records", "spf_records", "findings"):
                        row[key] = "; ".join(row[key])
                    row["dns_errors"] = json.dumps(row["dns_errors"], sort_keys=True)
                    writer.writerow({key: row.get(key, "") for key in CSV_FIELDS})
        elif report_format == "html":
            path.write_text(_html_report(results), encoding="utf-8")
        else:
            raise ValueError(f"Unsupported report format: {report_format}")
        paths.append(path)
    return paths


def _html_report(results: list[EmailResult]) -> str:
    rows = []
    for result in results:
        fields = (
            result.email,
            "Yes" if result.valid_syntax else "No",
            result.account_type,
            result.provider,
            result.risk_level,
            "; ".join(result.findings),
        )
        rows.append("<tr>" + "".join(f"<td>{html.escape(value)}</td>" for value in fields) + "</tr>")
    return """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<title>Zoho eClean report</title><style>
body{font:15px system-ui,sans-serif;margin:2rem;color:#172033}table{border-collapse:collapse;width:100%}
th,td{border:1px solid #d5dbe5;padding:.65rem;text-align:left}th{background:#edf2f8}
</style></head><body><h1>Zoho eClean report</h1>
<p>Syntax and public DNS analysis only. Mailbox existence was not tested.</p>
<table><thead><tr><th>Email</th><th>Syntax</th><th>Account/domain</th><th>Provider</th>
<th>Risk</th><th>Findings</th></tr></thead><tbody>""" + "".join(rows) + """</tbody></table>
</body></html>"""
