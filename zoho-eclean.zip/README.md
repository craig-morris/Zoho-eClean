# Zoho eClean

Zoho eClean is an interactive terminal dashboard for email syntax checks and
optional public DNS/provider intelligence. It supports Zoho Mail personal
domains and custom business domains, and produces local TXT and JSON reports.

**Syntax-valid does not mean a mailbox exists or can receive mail.** This app
does not check mailbox existence, log in, collect credentials/cookies, or test
SMTP authentication/delivery. DNS findings are domain-level indicators only.

## Install

Requirements: Python 3.11+ and internet access if DNS enrichment is selected.

### Windows PowerShell

```powershell
cd "C:\Users\brent\Downloads\Zoho eClean"
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python main.py
```

### Debian / Ubuntu

```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip
cd "Zoho eClean"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python main.py
```

After launch, use the arrow keys and Enter to navigate the colored dashboard.
The menu can process a list, change the input folder, upload selected reports
to Telegram, open the report folder, or exit.

## Input lists

By default, place input files in `data/input/`. The dashboard lists supported
`.txt` and `.csv` files in the selected folder:

- TXT: one address per line; blank lines and lines beginning with `#` are
  ignored.
- CSV: must have a column named `email` (case-insensitive).

Use **Change input folder** in the dashboard to choose a different directory.
Input lists are excluded from Git by default to avoid accidentally publishing
addresses.

## Large lists and accuracy

The batch processor reads input in bounded chunks (500 rows) and writes
reports incrementally instead of retaining the entire list or report in
memory. It supports lists of 100,000-150,000 rows, subject to available disk,
CPU, and resolver speed.

Choose **Fast syntax-only** for the fastest, entirely local analysis. Choose
**Public DNS/provider intelligence** to look up MX, TXT, and NS records. DNS
is requested once per unique domain (then cached for that run), with bounded
concurrency. A list with many unique domains will take longer and depends on
the machine's resolver. DNS lookups cannot prove that individual mailboxes
exist.

## Reports

Each run writes uniquely named files in `reports/output/`:

- `validation_summary_*.txt` — totals, provider/risk counts (when DNS is used),
  duration, and interpretation notes.
- `syntax_valid_emails_*.txt` — addresses passing syntax validation only.
- `invalid_syntax_emails_*.txt` — input lines failing syntax validation.
- `validation_report_*.json` — structured per-address results.

JSON output is split into valid array files at 20 MB per part so large runs
remain manageable and can be selected for Telegram uploads. These reports
contain the input addresses. Keep them private and only share them with
destinations you control.

## Telegram file posting

The dashboard's **Send TXT/JSON reports to Telegram** action uploads only the
files you select, after a confirmation prompt. Telegram bot token and chat ID
are read from environment variables; the app does not save them in project
files. If they are not set, the dashboard prompts for them (the token entry is
hidden) and keeps them in memory only until the app exits.

Alternatively, set both variables in the same terminal before launching:

PowerShell:

```powershell
$env:TELEGRAM_BOT_TOKEN = "your-bot-token"
$env:TELEGRAM_CHAT_ID = "your-chat-id"
python main.py
```

Debian / Ubuntu:

```bash
export TELEGRAM_BOT_TOKEN="your-bot-token"
export TELEGRAM_CHAT_ID="your-chat-id"
python main.py
```

Treat the bot token like a password. Only upload address reports to a bot/chat
you control and are authorized to use. Uploads are limited to Telegram's 50 MB
bot file limit. Do not paste the token into chat or commit it to source control.

## Tests

```powershell
python -m unittest discover -s tests -v
```
