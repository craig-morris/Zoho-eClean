import unittest
from unittest.mock import patch

from zoho_eclean.dashboard import run


class DashboardTests(unittest.TestCase):
    def test_exit_menu_action_returns_cleanly(self):
        with patch("zoho_eclean.dashboard._select", return_value="exit"):
            self.assertEqual(run(), 0)

    def test_keyboard_interrupt_returns_cleanly(self):
        with patch("zoho_eclean.dashboard._select", side_effect=KeyboardInterrupt):
            self.assertEqual(run(), 0)


if __name__ == "__main__":
    unittest.main()
