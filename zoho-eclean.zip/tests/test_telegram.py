import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from zoho_eclean.telegram import TelegramUploadError, credentials_available, send_document


class TelegramTests(unittest.TestCase):
    def test_credentials_are_read_from_environment(self):
        with patch.dict(os.environ, {"TELEGRAM_BOT_TOKEN": "token", "TELEGRAM_CHAT_ID": "chat"}):
            self.assertTrue(credentials_available())
        with patch.dict(os.environ, {}, clear=True):
            self.assertFalse(credentials_available())

    def test_upload_posts_selected_document(self):
        response = Mock()
        response.json.return_value = {"ok": True}
        with tempfile.TemporaryDirectory() as directory:
            report = Path(directory) / "summary.txt"
            report.write_text("summary", encoding="utf-8")
            with patch.dict(
                os.environ,
                {"TELEGRAM_BOT_TOKEN": "token", "TELEGRAM_CHAT_ID": "chat"},
            ), patch("zoho_eclean.telegram.requests.post", return_value=response) as post:
                send_document(report)
            self.assertEqual(post.call_args.args[0], "https://api.telegram.org/bottoken/sendDocument")
            self.assertEqual(post.call_args.kwargs["data"]["chat_id"], "chat")

    def test_upload_requires_credentials_and_supported_extension(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(TelegramUploadError):
                send_document(Path("report.txt"))

        with tempfile.TemporaryDirectory() as directory:
            report = Path(directory) / "report.csv"
            report.write_text("data", encoding="utf-8")
            with patch.dict(
                os.environ,
                {"TELEGRAM_BOT_TOKEN": "token", "TELEGRAM_CHAT_ID": "chat"},
            ):
                with self.assertRaises(TelegramUploadError):
                    send_document(report)


if __name__ == "__main__":
    unittest.main()
