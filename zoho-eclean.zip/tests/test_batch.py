import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from zoho_eclean.batch import process_file
from zoho_eclean.models import DNSResult


class BatchTests(unittest.TestCase):
    def test_syntax_only_batch_streams_and_writes_reports(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "input.txt"
            source.write_text(
                "\n".join(["user@example.org"] * 1001 + ["not-an-email"]),
                encoding="utf-8",
            )
            progress = []
            summary = process_file(
                source,
                root / "output",
                check_dns=False,
                progress=lambda *values: progress.append(values),
            )

            self.assertEqual(summary["processed"], 1002)
            self.assertEqual(summary["valid"], 1001)
            self.assertEqual(summary["invalid"], 1)
            self.assertTrue(progress)
            self.assertEqual(len(summary["files"]), 4)
            report = next(path for path in summary["files"] if path.suffix == ".json")
            self.assertEqual(len(json.loads(report.read_text(encoding="utf-8"))), 1002)

    def test_dns_lookup_is_cached_by_domain(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "input.txt"
            source.write_text(
                "\n".join(["user@example.org"] * 600),
                encoding="utf-8",
            )
            records = DNSResult(
                mx=["10 mx.example.org"],
                txt=["v=spf1 -all"],
                ns=["ns.example.org"],
                errors={},
            )
            with patch("zoho_eclean.batch.lookup_domain", return_value=records) as lookup:
                summary = process_file(
                    source,
                    root / "output",
                    check_dns=True,
                    workers=2,
                )

            self.assertEqual(summary["processed"], 600)
            lookup.assert_called_once_with("example.org", 2.0)

    def test_csv_email_header_is_case_insensitive(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "input.csv"
            source.write_text("Email,Name\nuser@example.org,User\n", encoding="utf-8")
            summary = process_file(source, root / "output", check_dns=False)
            self.assertEqual(summary["valid"], 1)

    def test_large_json_report_is_split_into_valid_parts(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "input.txt"
            source.write_text("\n".join(["user@example.org"] * 30), encoding="utf-8")
            with patch("zoho_eclean.batch.MAX_JSON_PART_BYTES", 800):
                summary = process_file(source, root / "output", check_dns=False)
            reports = [path for path in summary["files"] if path.suffix == ".json"]
            self.assertGreater(len(reports), 1)
            self.assertTrue(all(isinstance(json.loads(path.read_text(encoding="utf-8")), list) for path in reports))


if __name__ == "__main__":
    unittest.main()
