import tempfile
import unittest
from pathlib import Path

from zoho_eclean.analysis import analyze, identify_provider
from zoho_eclean.models import DNSResult
from zoho_eclean.reporting import write_report


class AnalysisTests(unittest.TestCase):
    def test_zoho_hosted_business_domain(self):
        result = analyze(
            "admin@example.org",
            dns_result=DNSResult(
                mx=["10 mx.zoho.com", "20 mx2.zoho.com"],
                txt=["v=spf1 include:zoho.com ~all"],
                ns=["ns1.example.org"],
                errors={},
            ),
        )
        self.assertTrue(result.valid_syntax)
        self.assertEqual(result.provider, "Zoho Mail")
        self.assertEqual(result.account_type, "Zoho-hosted business/custom domain")
        self.assertEqual(result.risk_level, "Low")

    def test_personal_zoho_domain(self):
        result = analyze(
            "User@Zoho.com",
            dns_result=DNSResult(mx=[], txt=[], ns=[], errors={}),
        )
        self.assertEqual(result.email, "User@zoho.com")
        self.assertEqual(result.account_type, "Zoho Mail personal domain")

    def test_invalid_syntax_skips_dns(self):
        result = analyze("not-an-email")
        self.assertFalse(result.valid_syntax)
        self.assertEqual(result.provider, "Not checked")
        self.assertEqual(result.dns_errors, {})

    def test_provider_detection_handles_regional_zoho_mx(self):
        self.assertEqual(identify_provider(["10 mx.zoho.eu"])[0], "Zoho Mail")

    def test_provider_detection_does_not_match_lookalike_mx_host(self):
        self.assertEqual(identify_provider(["10 mx.notzoho.com"])[0], "Unknown / custom")

    def test_dns_failures_are_not_reported_as_missing_records(self):
        result = analyze(
            "user@example.org",
            dns_result=DNSResult(
                mx=[],
                txt=[],
                ns=[],
                errors={"mx": "DNS query failed: LifetimeTimeout.", "txt": "DNS query failed: LifetimeTimeout."},
            ),
        )
        self.assertEqual(result.provider, "DNS lookup failed")
        self.assertEqual(result.risk_level, "Incomplete")
        self.assertEqual(result.risk_score, 0)
        self.assertFalse(any("No MX records" in finding for finding in result.findings))

    def test_all_report_formats_are_written(self):
        result = analyze(
            "user@example.org",
            dns_result=DNSResult(mx=[], txt=[], ns=[], errors={}),
        )
        with tempfile.TemporaryDirectory() as directory:
            paths = write_report([result], Path(directory), ["csv", "json", "html"])
            self.assertEqual({path.suffix for path in paths}, {".csv", ".json", ".html"})
            self.assertTrue(all(path.exists() and path.stat().st_size > 0 for path in paths))


if __name__ == "__main__":
    unittest.main()
